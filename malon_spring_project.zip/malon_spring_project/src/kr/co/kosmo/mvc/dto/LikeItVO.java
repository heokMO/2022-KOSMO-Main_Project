package kr.co.kosmo.mvc.dto;

public class LikeItVO {
	private String mem_acc_id;
	private int song_id;
	public String getMem_acc_id() {
		return mem_acc_id;
	}
	public void setMem_acc_id(String mem_acc_id) {
		this.mem_acc_id = mem_acc_id;
	}
	public int getSong_id() {
		return song_id;
	}
	public void setSong_id(int song_id) {
		this.song_id = song_id;
	}
	
	
}
