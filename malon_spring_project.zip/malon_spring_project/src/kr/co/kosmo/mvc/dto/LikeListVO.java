package kr.co.kosmo.mvc.dto;

public class LikeListVO {

}
